/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "NotifyListener.h"

#ifdef __cplusplus
extern "C" {
#endif


void* HALSIM_CreateADXL345I2CAccelerometerData(int32_t port);
void HALSIM_DestroyADXL345I2CAccelerometerData(void* data);


void HALSIM_ResetADXL345I2CAccelerometerData(void* data);

int32_t HALSIM_RegisterADXL345I2CAccelerometerXCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL345I2CAccelerometerXCallback(void* data, int32_t uid);
double HALSIM_GetADXL345I2CAccelerometerX(void* data);
void HALSIM_SetADXL345I2CAccelerometerX(void* data, double x);

int32_t HALSIM_RegisterADXL345I2CAccelerometerYCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL345I2CAccelerometerYCallback(void* data, int32_t uid);
double HALSIM_GetADXL345I2CAccelerometerY(void* data);
void HALSIM_SetADXL345I2CAccelerometerY(void* data, double y);

int32_t HALSIM_RegisterADXL345I2CAccelerometerZCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL345I2CAccelerometerZCallback(void* data, int32_t uid);
double HALSIM_GetADXL345I2CAccelerometerZ(void* data);
void HALSIM_SetADXL345I2CAccelerometerZ(void* data, double z);

#ifdef __cplusplus
}
#endif
