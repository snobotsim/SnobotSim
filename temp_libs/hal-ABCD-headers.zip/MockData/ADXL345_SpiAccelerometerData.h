/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "NotifyListener.h"

#ifdef __cplusplus
extern "C" {
#endif

void* HALSIM_CreateADXL345SPIAccelerometerData(int32_t port);
void HALSIM_DestroyADXL345SPIAccelerometerData(void* data);


void HALSIM_ResetADXL345SPIAccelerometerData(void* data);

int32_t HALSIM_RegisterADXL345SPIAccelerometerXCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL345SPIAccelerometerXCallback(void* data, int32_t uid);
double HALSIM_GetADXL345SPIAccelerometerX(void* data);
void HALSIM_SetADXL345SPIAccelerometerX(void* data, double x);

int32_t HALSIM_RegisterADXL345SPIAccelerometerYCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL345SPIAccelerometerYCallback(void* data, int32_t uid);
double HALSIM_GetADXL345SPIAccelerometerY(void* data);
void HALSIM_SetADXL345SPIAccelerometerY(void* data, double y);

int32_t HALSIM_RegisterADXL345SPIAccelerometerZCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL345SPIAccelerometerZCallback(void* data, int32_t uid);
double HALSIM_GetADXL345SPIAccelerometerZ(void* data);
void HALSIM_SetADXL345SPIAccelerometerZ(void* data, double z);

#ifdef __cplusplus
}
#endif
