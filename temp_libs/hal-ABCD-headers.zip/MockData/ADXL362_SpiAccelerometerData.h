/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "NotifyListener.h"

#ifdef __cplusplus
extern "C" {
#endif

void* HALSIM_CreateADXL362SPIAccelerometerData(int32_t port);
void HALSIM_DestroyADXL362SPIAccelerometerData(void* data);

void HALSIM_ResetADXL362SPIAccelerometerData(void* data);

int32_t HALSIM_RegisterADXL362SPIAccelerometerXCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL362SPIAccelerometerXCallback(void* data, int32_t uid);
double HALSIM_GetADXL362SPIAccelerometerX(void* data);
void HALSIM_SetADXL362SPIAccelerometerX(void* data, double x);

int32_t HALSIM_RegisterADXL362SPIAccelerometerYCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL362SPIAccelerometerYCallback(void* data, int32_t uid);
double HALSIM_GetADXL362SPIAccelerometerY(void* data);
void HALSIM_SetADXL362SPIAccelerometerY(void* data, double y);

int32_t HALSIM_RegisterADXL362SPIAccelerometerZCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXL362SPIAccelerometerZCallback(void* data, int32_t uid);
double HALSIM_GetADXL362SPIAccelerometerZ(void* data);
void HALSIM_SetADXL362SPIAccelerometerZ(void* data, double z);

#ifdef __cplusplus
}
#endif
