/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "NotifyListener.h"

#ifdef __cplusplus
extern "C" {
#endif

void* HALSIM_CreateADXRS450SPIGyroData(int32_t port);
void HALSIM_DestroyADXRS450SPIGyroData(void* data);

void HALSIM_ResetADXRS450SPIGyroData(void* data);

int32_t HALSIM_RegisterADXRS450SPIGyroAngleCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify);
void HALSIM_CancelADXRS450SPIGyroAngleCallback(void* data, int32_t uid);
double HALSIM_GetADXRS450SPIGyroAngle(void* data);
void HALSIM_SetADXRS450SPIGyroAngle(void* data, double x);

#ifdef __cplusplus
}
#endif
