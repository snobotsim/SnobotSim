/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#include <iostream>

#include "CANDataInternal.h"
#include "NotifyCallbackHelpers.h"

using namespace hal;

CANData hal::SimCANData;

static const int MAX_CAN_BUFFER_SIZE = 20;

CANData::CANData()
{
  m_lastSendMessageData = new uint8_t[MAX_CAN_BUFFER_SIZE];
  m_readBuffer = new uint8_t[MAX_CAN_BUFFER_SIZE];
  m_readStreamBuffer = new HAL_CANStreamMessage[MAX_CAN_BUFFER_SIZE];
}

CANData::~CANData()
{
  delete[] m_lastSendMessageData;
  delete[] m_readBuffer;
  delete[] m_readStreamBuffer;
}

void CANData::Reset()
{
  m_sendMessageCallback = nullptr;
  m_receiveMessageCallback = nullptr;
  m_openStreamSessionCallback = nullptr;
  m_closeStreamSessionCallback = nullptr;

  m_readStreamSessionCallback = nullptr;
  m_getCANStatusCallback = nullptr;

  std::memset(&m_lastSendMessageData[0], 0, MAX_CAN_BUFFER_SIZE);
  std::memset(&m_readBuffer[0], 0, MAX_CAN_BUFFER_SIZE);
  std::memset(&m_readStreamBuffer[0], 0, MAX_CAN_BUFFER_SIZE);
}


#define XXXXXX(CallbackName, CallbackVariable, Text)                              \
int32_t CANData::Register##CallbackName(HAL_NotifyCallback callback,              \
                                           void* param,                           \
                                           HAL_Bool initialNotify) {              \
  if (callback == nullptr) return -1;                                             \
  int32_t newUid = 0;                                                             \
  {                                                                               \
    std::lock_guard<std::mutex> lock(m_registerMutex);                            \
    CallbackVariable =                                                            \
        RegisterCallback(CallbackVariable, Text, callback, param, &newUid);       \
  }                                                                               \
  return newUid;                                                                  \
}                                                                                 \
                                                                                  \
void CANData::Cancel##CallbackName(int32_t uid) {                                 \
	CallbackVariable = CancelCallback(CallbackVariable, uid);                     \
}                                                                                 \


#define YYY                                                                             \
XXXXXX(SendMessageCallback, m_sendMessageCallback, "SendMessage")                       \
XXXXXX(ReceiveMessageCallback, m_receiveMessageCallback, "ReceiveMessage")              \
XXXXXX(OpenStreamSessionCallback, m_openStreamSessionCallback, "OpenStreamSession")     \
XXXXXX(CloseStreamSessionCallback, m_closeStreamSessionCallback, "CloseStreamSession")  \
XXXXXX(ReadStreamSessionCallback, m_readStreamSessionCallback, "ReadStreamSession")     \
XXXXXX(GetCANStatusCallback, m_getCANStatusCallback, "GetCANStatus")

YYY




void CANData::SendMessage(uint32_t messageID, const uint8_t* data,
                          uint8_t dataSize, int32_t periodMs, int32_t* status)
{
  std::memcpy(&m_lastSendMessageData[0], &data[0], dataSize);

  HAL_Value value = MakeInt(messageID);
  InvokeSendMessageCallback(value);
}

void CANData::ReceiveMessage(uint32_t* messageID, uint32_t messageIDMask,
                             uint8_t* data, uint8_t* dataSize,
                             uint32_t* timeStamp, int32_t* status)
{
  HAL_Value value = MakeInt(*messageID);
  InvokeReceiveMessageCallback(value);

  *dataSize = 8;
  std::memcpy(&data[0], &m_readBuffer[0], *dataSize);
}

void CANData::ReadStreamSession(uint32_t sessionHandle,
		struct HAL_CANStreamMessage* messages,
        uint32_t messagesToRead, uint32_t* messagesRead,
        int32_t* status)
{
  *messagesRead = 1;

  HAL_Value value = MakeInt(sessionHandle);
  InvokeReadStreamSessionCallback(value);

  std::memcpy(&messages[0], &m_readStreamBuffer[0], sizeof(HAL_CANStreamMessage) * (*messagesRead));
}

void CANData::OpenStreamSession(uint32_t* sessionHandle, uint32_t messageID,
                                uint32_t messageIDMask, uint32_t maxMessages,
                                int32_t* status)
{
  static int sessionCtr = 1;

  *sessionHandle = sessionCtr++;
  HAL_Value value = MakeInt(messageID);
  InvokeOpenStreamSessionCallback(value);
}


void CANData::CloseStreamSession(uint32_t sessionHandle)
{
  HAL_Value value = MakeInt(sessionHandle);
  InvokeCloseStreamSessionCallback(value);
}

void CANData::GetCANStatus(float* percentBusUtilization, uint32_t* busOffCount,
                           uint32_t* txFullCount, uint32_t* receiveErrorCount,
                           uint32_t* transmitErrorCount, int32_t* status)
{
  HAL_Value value = MakeBoolean(true);
  InvokeGetCANStatusCallback(value);
}

void CANData::InvokeSendMessageCallback(HAL_Value& value)
{
  InvokeCallback(m_sendMessageCallback, "SendMessage", &value);
}

void CANData::InvokeReceiveMessageCallback(HAL_Value& value)
{
  InvokeCallback(m_receiveMessageCallback, "ReceiveMessage", &value);
}

void CANData::InvokeOpenStreamSessionCallback(HAL_Value& value)
{
  InvokeCallback(m_openStreamSessionCallback, "OpenStreamSession", &value);
}

void CANData::InvokeCloseStreamSessionCallback(HAL_Value& value)
{
  InvokeCallback(m_closeStreamSessionCallback, "CloseStreamSession", &value);
}

void CANData::InvokeReadStreamSessionCallback(HAL_Value& value)
{
  InvokeCallback(m_readStreamSessionCallback, "ReadStreamSession", &value);
}
void CANData::InvokeGetCANStatusCallback(HAL_Value& value)
{
  InvokeCallback(m_getCANStatusCallback, "GetCANStatus", &value);
}

////////////////////////
// Simulator Accessors
////////////////////////
void CANData::GetLastSentMessageData(uint8_t* buffer, int32_t count)
{
  if(count < MAX_CAN_BUFFER_SIZE)
  {
	std::memcpy(&buffer[0], &m_lastSendMessageData[0], count);
  }
  else
  {
	std::cout << "Trying to put too much data into buffer. " <<
			"Request: " << count << ", Max: " << MAX_CAN_BUFFER_SIZE << std::endl;
  }
}

void CANData::SetValueForRead(uint8_t* buffer, int32_t count)
{
  if(count < MAX_CAN_BUFFER_SIZE)
  {
	std::memcpy(&m_readBuffer[0], &buffer[0], count);
  }
  else
  {
	std::cout << "Trying to put too much data into read buffer. " <<
			"Request: " << count << ", Max: " << MAX_CAN_BUFFER_SIZE << std::endl;
  }
}

void CANData::SetMessagesForReadStream(struct HAL_CANStreamMessage* messages, int32_t count)
{
  if(count < MAX_CAN_BUFFER_SIZE)
  {
	std::memcpy(&m_readStreamBuffer[0], &messages[0], sizeof(HAL_CANStreamMessage) * count);
  }
  else
  {
	std::cout << "Trying to put too much data into read buffer. " <<
			"Request: " << count << ", Max: " << MAX_CAN_BUFFER_SIZE << std::endl;
  }
}

extern "C" {


void HALSIM_ResetCAN()
{
	SimCANData.Reset();
}

/////////////////////////////////////////
// Send Message
/////////////////////////////////////////
int32_t HALSIM_RegisterCANSendMessageCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify)
{
  return SimCANData.RegisterSendMessageCallback(callback, param, initialNotify);
}
void HALSIM_CancelCANSendMessageCallback(int32_t index, int32_t uid)
{
  SimCANData.CancelSendMessageCallback(uid);
}

/////////////////////////////////////////
// Receive Message
/////////////////////////////////////////
int32_t HALSIM_RegisterCANReceiveMessageCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify)
{
  return SimCANData.RegisterReceiveMessageCallback(callback, param, initialNotify);
}
void HALSIM_CancelCANReceiveMessageCallback(int32_t index, int32_t uid)
{
  SimCANData.CancelReceiveMessageCallback(uid);
}

/////////////////////////////////////////
// Open Stream Session
/////////////////////////////////////////
int32_t HALSIM_RegisterCANOpenStreamSessionCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify)
{
  return SimCANData.RegisterOpenStreamSessionCallback(callback, param,
													   initialNotify);
}
void HALSIM_CancelCANOpenStreamSessionCallback(int32_t index, int32_t uid)
{
  SimCANData.CancelOpenStreamSessionCallback(uid);
}


/////////////////////////////////////////
// Close Stream Session
/////////////////////////////////////////
int32_t HALSIM_RegisterCANCloseStreamSessionCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify)
{
  return SimCANData.RegisterCloseStreamSessionCallback(callback, param,
													   initialNotify);
}
void HALSIM_CancelCANCloseStreamSessionCallback(int32_t index, int32_t uid)
{
  SimCANData.CancelCloseStreamSessionCallback(uid);
}


/////////////////////////////////////////
// Read Stream Session
/////////////////////////////////////////
int32_t HALSIM_RegisterCANReadStreamSessionCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify)
{
  return SimCANData.RegisterReadStreamSessionCallback(callback, param,
													   initialNotify);
}
void HALSIM_CancelCANReadStreamSessionCallback(int32_t index, int32_t uid)
{
  SimCANData.CancelReadStreamSessionCallback(uid);
}


/////////////////////////////////////////
// Get CAN Status
/////////////////////////////////////////
int32_t HALSIM_RegisterCANGetCANStatusCallback(int32_t index,
                                                   HAL_NotifyCallback callback,
                                                   void* param,
                                                   HAL_Bool initialNotify)
{
  return SimCANData.RegisterGetCANStatusCallback(callback, param,
													   initialNotify);
}
void HALSIM_CancelCANGetCANStatusCallback(int32_t index, int32_t uid)
{
  SimCANData.CancelGetCANStatusCallback(uid);
}

/////////////////////////////////////////
// Getters
/////////////////////////////////////////
void HALSIM_GetCANLastSentMessageData(uint8_t* buffer, int32_t count)
{
  SimCANData.GetLastSentMessageData(buffer, count);
}
void HALSIM_SetCANValueForRead(uint8_t* buffer, int32_t count)
{
  SimCANData.SetValueForRead(buffer, count);
}

void HALSIM_SetCANMessagesForReadStream(struct HAL_CANStreamMessage* messages, int32_t count)
{
  SimCANData.SetMessagesForReadStream(messages, count);
}

}
