/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "MockData/NotifyListenerVector.h"


namespace hal {
class CANData {

public:

  CANData();
  ~CANData();

  ////////////////////////
  // Callbacks
  ////////////////////////
  int32_t RegisterSendMessageCallback(HAL_NotifyCallback callback, void* param, HAL_Bool initialNotify);
  void CancelSendMessageCallback(int32_t uid);

  int32_t RegisterReceiveMessageCallback(HAL_NotifyCallback callback, void* param, HAL_Bool initialNotify);
  void CancelReceiveMessageCallback(int32_t uid);

  int32_t RegisterOpenStreamSessionCallback(HAL_NotifyCallback callback, void* param, HAL_Bool initialNotify);
  void CancelOpenStreamSessionCallback(int32_t uid);

  int32_t RegisterCloseStreamSessionCallback(HAL_NotifyCallback callback, void* param, HAL_Bool initialNotify);
  void CancelCloseStreamSessionCallback(int32_t uid);

  int32_t RegisterReadStreamSessionCallback(HAL_NotifyCallback callback, void* param, HAL_Bool initialNotify);
  void CancelReadStreamSessionCallback(int32_t uid);

  int32_t RegisterGetCANStatusCallback(HAL_NotifyCallback callback, void* param, HAL_Bool initialNotify);
  void CancelGetCANStatusCallback(int32_t uid);

  ////////////////////////
  // HAL Functions
  ////////////////////////
  void Reset();

  void SendMessage(uint32_t messageID, const uint8_t* data,
                   uint8_t dataSize, int32_t periodMs, int32_t* status);

  void ReceiveMessage(uint32_t* messageID, uint32_t messageIDMask,
                      uint8_t* data, uint8_t* dataSize,
                      uint32_t* timeStamp, int32_t* status);

  void OpenStreamSession(uint32_t* sessionHandle, uint32_t messageID,
                         uint32_t messageIDMask, uint32_t maxMessages,
                         int32_t* status);

//  void ReadStreamSession(uint32_t sessionHandle,
//                         struct HAL_CANStreamMessage* messages,
//                         uint32_t messagesToRead, uint32_t* messagesRead,
//                         int32_t* status);

  void CloseStreamSession(uint32_t sessionHandle);

  void GetCANStatus(float* percentBusUtilization, uint32_t* busOffCount,
                    uint32_t* txFullCount, uint32_t* receiveErrorCount,
                    uint32_t* transmitErrorCount, int32_t* status);

  ////////////////////////
  // Simulator Accessors
  ////////////////////////
  void GetLastSentMessageData(uint8_t* buffer, int32_t count);
  void SetValueForRead(uint8_t* buffer, int32_t count);

private:

  void InvokeSendMessageCallback(HAL_Value& value);
  void InvokeReceiveMessageCallback(HAL_Value& value);
  void InvokeOpenStreamSessionCallback(HAL_Value& value);
  void InvokeCloseStreamSessionCallback(HAL_Value& value);

  void InvokeReadStreamSessionCallback(HAL_Value& value);
  void InvokeGetCANStatusCallback(HAL_Value& value);

  std::mutex m_registerMutex;

  std::shared_ptr<NotifyListenerVector> m_sendMessageCallback = nullptr;
  std::shared_ptr<NotifyListenerVector> m_receiveMessageCallback = nullptr;
  std::shared_ptr<NotifyListenerVector> m_openStreamSessionCallback = nullptr;
  std::shared_ptr<NotifyListenerVector> m_closeStreamSessionCallback = nullptr;

  // TODO temp
  std::shared_ptr<NotifyListenerVector> m_readStreamSessionCallback = nullptr;
  std::shared_ptr<NotifyListenerVector> m_getCANStatusCallback = nullptr;

  uint8_t* m_lastSendMessageData;
  uint8_t* m_readBuffer;
};

extern CANData SimCANData;

}
