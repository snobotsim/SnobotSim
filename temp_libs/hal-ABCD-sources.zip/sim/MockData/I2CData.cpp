/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#include "../PortsInternal.h"
#include "NotifyCallbackHelpers.h"
#include "I2CDataInternal.h"

using namespace hal;

I2CData hal::SimI2CData[2];

void I2CData::ResetData() {
  m_initialized = false;
  m_initializedCallbacks = nullptr;
}

int32_t I2CData::RegisterInitializedCallback(HAL_NotifyCallback callback,
                                             void* param,
                                             HAL_Bool initialNotify) {
  // Must return -1 on a null callback for error handling
  if (callback == nullptr) return -1;
  int32_t newUid = 0;
  {
    std::lock_guard<std::mutex> lock(m_registerMutex);
    m_initializedCallbacks = RegisterCallback(
        m_initializedCallbacks, "Initialized", callback, param, &newUid);
  }
  if (initialNotify) {
    // We know that the callback is not null because of earlier null check
    HAL_Value value = MakeBoolean(GetInitialized());
    callback("Initialized", param, &value);
  }
  return newUid;
}

void I2CData::CancelInitializedCallback(int32_t uid) {
  m_initializedCallbacks = CancelCallback(m_initializedCallbacks, uid);
}

void I2CData::InvokeInitializedCallback(HAL_Value value) {
  InvokeCallback(m_initializedCallbacks, "Initialized", &value);
}

HAL_Bool I2CData::GetInitialized() { return m_initialized; }

void I2CData::SetInitialized(HAL_Bool initialized) {
  HAL_Bool oldValue = m_initialized.exchange(initialized);
  if (oldValue != initialized) {
    InvokeInitializedCallback(MakeBoolean(initialized));
  }
}


extern "C" {
void HALSIM_ResetI2CData(int32_t index) {
  SimI2CData[index].ResetData();
}

int32_t HALSIM_RegisterI2CInitializedCallback(int32_t index,
                                                  HAL_NotifyCallback callback,
                                                  void* param,
                                                  HAL_Bool initialNotify) {
  return SimI2CData[index].RegisterInitializedCallback(callback, param,
                                                           initialNotify);
}

void HALSIM_CancelI2CInitializedCallback(int32_t index, int32_t uid) {
  SimI2CData[index].CancelInitializedCallback(uid);
}

HAL_Bool HALSIM_GetI2CInitialized(int32_t index) {
  return SimI2CData[index].GetInitialized();
}

void HALSIM_SetI2CInitialized(int32_t index, HAL_Bool initialized) {
  SimI2CData[index].SetInitialized(initialized);
}

} // extern c
