/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#include <iostream>

#include "../PortsInternal.h"
#include "NotifyCallbackHelpers.h"
#include "SPIDataInternal.h"

using namespace hal;

SPIData hal::SimSPIData[5];
static const int MAX_SPI_BUFFER_SIZE = 200;

void SPIData::ResetData() {
  m_initialized = false;
  m_accumulatorValue = 0;
  m_initializedCallbacks = nullptr;
  m_readCallbacks = nullptr;
  m_writeCallbacks = nullptr;
  m_transactionCallbacks = nullptr;

  std::memset(&m_readBuffer[0], 0, MAX_SPI_BUFFER_SIZE);
  std::memset(&m_writeBuffer[0], 0, MAX_SPI_BUFFER_SIZE);
  std::memset(&m_transactionBuffer[0], 0, MAX_SPI_BUFFER_SIZE);
}

SPIData::SPIData()
{
	m_readBuffer = new uint8_t[MAX_SPI_BUFFER_SIZE];
	m_writeBuffer = new uint8_t[MAX_SPI_BUFFER_SIZE];
	m_transactionBuffer = new uint8_t[MAX_SPI_BUFFER_SIZE];
}
SPIData::~SPIData()
{
  delete m_readBuffer;
  delete m_writeBuffer;
  delete m_transactionBuffer;
}

///////////////////////////////////////////
// Initialize
///////////////////////////////////////////
int32_t SPIData::RegisterInitializedCallback(HAL_NotifyCallback callback,
                                             void* param,
                                             HAL_Bool initialNotify) {
  // Must return -1 on a null callback for error handling
  if (callback == nullptr) return -1;
  int32_t newUid = 0;
  {
    std::lock_guard<std::mutex> lock(m_registerMutex);
    m_initializedCallbacks = RegisterCallback(
        m_initializedCallbacks, "Initialized", callback, param, &newUid);
  }
  if (initialNotify) {
    // We know that the callback is not null because of earlier null check
    HAL_Value value = MakeBoolean(GetInitialized());
    callback("Initialized", param, &value);
  }
  return newUid;
}

void SPIData::CancelInitializedCallback(int32_t uid) {
  m_initializedCallbacks = CancelCallback(m_initializedCallbacks, uid);
}

void SPIData::InvokeInitializedCallback(HAL_Value value) {
  InvokeCallback(m_initializedCallbacks, "Initialized", &value);
}

HAL_Bool SPIData::GetInitialized() { return m_initialized; }

void SPIData::SetInitialized(HAL_Bool initialized) {
  HAL_Bool oldValue = m_initialized.exchange(initialized);
  if (oldValue != initialized) {
    InvokeInitializedCallback(MakeBoolean(initialized));
  }
}

///////////////////////////////////////////
// Read
///////////////////////////////////////////
int32_t SPIData::RegisterReadCallback(HAL_NotifyCallback callback,
                                             void* param,
                                             HAL_Bool initialNotify) {
  // Must return -1 on a null callback for error handling
  if (callback == nullptr) return -1;
  int32_t newUid = 0;
  {
    std::lock_guard<std::mutex> lock(m_registerMutex);
    m_readCallbacks = RegisterCallback(
    		m_readCallbacks, "Read", callback, param, &newUid);
  }
  if (initialNotify) {
    // We know that the callback is not null because of earlier null check
    HAL_Value value = MakeBoolean(GetInitialized());
    callback("Read", param, &value);
  }
  return newUid;
}

void SPIData::CancelReadCallback(int32_t uid) {
	m_readCallbacks = CancelCallback(m_readCallbacks, uid);
}


///////////////////////////////////////////
// Write
///////////////////////////////////////////
int32_t SPIData::RegisterWriteCallback(HAL_NotifyCallback callback,
                                             void* param,
                                             HAL_Bool initialNotify) {
  // Must return -1 on a null callback for error handling
  if (callback == nullptr) return -1;
  int32_t newUid = 0;
  {
    std::lock_guard<std::mutex> lock(m_registerMutex);
    m_writeCallbacks = RegisterCallback(
    		m_writeCallbacks, "Write", callback, param, &newUid);
  }
  if (initialNotify) {
    // We know that the callback is not null because of earlier null check
    HAL_Value value = MakeBoolean(GetInitialized());
    callback("Write", param, &value);
  }
  return newUid;
}

void SPIData::CancelWriteCallback(int32_t uid) {
	m_writeCallbacks = CancelCallback(m_writeCallbacks, uid);
}


///////////////////////////////////////////
// Transaction
///////////////////////////////////////////
int32_t SPIData::RegisterTransactionCallback(HAL_NotifyCallback callback,
                                             void* param,
                                             HAL_Bool initialNotify) {
  // Must return -1 on a null callback for error handling
  if (callback == nullptr) return -1;
  int32_t newUid = 0;
  {
    std::lock_guard<std::mutex> lock(m_registerMutex);
    m_transactionCallbacks = RegisterCallback(
    		m_transactionCallbacks, "Transaction", callback, param, &newUid);
  }
  if (initialNotify) {
    // We know that the callback is not null because of earlier null check
    HAL_Value value = MakeBoolean(GetInitialized());
    callback("Transaction", param, &value);
  }
  return newUid;
}

void SPIData::CancelTransactionCallback(int32_t uid) {
	m_transactionCallbacks = CancelCallback(m_transactionCallbacks, uid);
}


////////////////////////////////////////////////////////
// HAL Functions
////////////////////////////////////////////////////////
int32_t SPIData::Read(uint8_t* buffer, int32_t count)
{
	HAL_Value value = MakeInt(count);
	InvokeCallback(m_readCallbacks, "Read", &value);

    std::memcpy(&buffer[0], &m_readBuffer[0], count);

    return count;
}

int32_t SPIData::Write(uint8_t* dataToSend, int32_t sendSize)
{
    std::memcpy(&m_writeBuffer[0], &dataToSend[0], sendSize);

	HAL_Value value = MakeInt(sendSize);
	InvokeCallback(m_writeCallbacks, "Write", &value);

    return sendSize;
}

int32_t SPIData::Transaction(uint8_t* dataToSend, uint8_t* dataReceived, int32_t size)
{
    std::memcpy(&m_transactionBuffer[0], &dataToSend[0], size);

	HAL_Value value = MakeInt(size);
	InvokeCallback(m_transactionCallbacks, "Transaction", &value);

  return Read(dataReceived, size);
}

////////////////////////////////
// Simulator Accessors
////////////////////////////////
void SPIData::SetAccumulatorValue(int64_t value)
{
  int64_t oldValue = m_accumulatorValue.exchange(value);
  if (oldValue != value) {
	std::cout << "New accumulator value... " << value << std::endl;
  }
}

int64_t SPIData::GetAccumulatorValue()
{
  return m_accumulatorValue;
}

void SPIData::SetValueForRead(uint8_t* buffer, int32_t count)
{
  if(count < MAX_SPI_BUFFER_SIZE)
  {
	std::memcpy(&m_readBuffer[0], &buffer[0], count);
  }
  else
  {
	std::cout << "Trying to put too much data into read buffer. " <<
			"Request: " << count << ", Max: " << MAX_SPI_BUFFER_SIZE << std::endl;
  }
}

void SPIData::GetWriteBuffer(uint8_t* buffer, int32_t count)
{
  if(count < MAX_SPI_BUFFER_SIZE)
  {
	std::memcpy(&buffer[0], &m_writeBuffer[0], count);
  }
  else
  {
	std::cout << "Trying to read too much data into write buffer. " <<
			"Request: " << count << ", Max: " << MAX_SPI_BUFFER_SIZE << std::endl;
  }
}

void SPIData::GetTransactionBuffer(uint8_t* buffer, int32_t count)
{
	  if(count < MAX_SPI_BUFFER_SIZE)
	  {
		std::memcpy(&buffer[0], &m_transactionBuffer[0], count);
	  }
	  else
	  {
		std::cout << "Trying to read too much data into write buffer. " <<
				"Request: " << count << ", Max: " << MAX_SPI_BUFFER_SIZE << std::endl;
	  }
}


extern "C" {
void HALSIM_ResetSPIData(int32_t index) {
  SimSPIData[index].ResetData();
}

///////////////////////////////////
// Initialize
///////////////////////////////////
int32_t HALSIM_RegisterSPIInitializedCallback(int32_t index,
                                                  HAL_NotifyCallback callback,
                                                  void* param,
                                                  HAL_Bool initialNotify) {
  return SimSPIData[index].RegisterInitializedCallback(callback, param,
                                                           initialNotify);
}

void HALSIM_CancelSPIInitializedCallback(int32_t index, int32_t uid) {
  SimSPIData[index].CancelInitializedCallback(uid);
}

HAL_Bool HALSIM_GetSPIInitialized(int32_t index) {
  return SimSPIData[index].GetInitialized();
}

void HALSIM_SetSPIInitialized(int32_t index, HAL_Bool initialized) {
  SimSPIData[index].SetInitialized(initialized);
}

///////////////////////////////////
// Read
///////////////////////////////////
int32_t HALSIM_RegisterSPIReadCallback(int32_t index,
                                          HAL_NotifyCallback callback,
                                          void* param,
										  HAL_Bool initialNotify) {
  return SimSPIData[index].RegisterReadCallback(callback, param, initialNotify);
}
void HALSIM_CancelSPIReadCallback(int32_t index,
                                     int32_t uid) {
  SimSPIData[index].CancelReadCallback(uid);
}

///////////////////////////////////
// Write
///////////////////////////////////
int32_t HALSIM_RegisterSPIWriteCallback(int32_t index,
                                          HAL_NotifyCallback callback,
                                          void* param,
										  HAL_Bool initialNotify) {
  return SimSPIData[index].RegisterWriteCallback(callback, param, initialNotify);
}
void HALSIM_CancelSPIWriteCallback(int32_t index,
                                     int32_t uid) {
  SimSPIData[index].CancelWriteCallback(uid);
}

///////////////////////////////////
// Transaction
///////////////////////////////////
int32_t HALSIM_RegisterSPITransactionCallback(int32_t index,
                                          HAL_NotifyCallback callback,
                                          void* param,
										  HAL_Bool initialNotify) {
  return SimSPIData[index].RegisterTransactionCallback(callback, param, initialNotify);
}
void HALSIM_CancelSPITransactionCallback(int32_t index,
                                     int32_t uid) {
  SimSPIData[index].CancelTransactionCallback(uid);
}


///////////////////////////////////
// Setters
///////////////////////////////////
void HALSIM_SetSPIGetAccumulatorValue(int32_t index, int64_t value)
{
  SimSPIData[index].SetAccumulatorValue(value);
}
void HALSIM_SetSPISetValueForRead(int32_t index, uint8_t* buffer, int32_t count)
{
	SimSPIData[index].SetValueForRead(buffer, count);
}

void HALSIM_GetSPIGetWriteBuffer(int32_t index, uint8_t* buffer, int32_t count)
{
	SimSPIData[index].GetWriteBuffer(buffer, count);
}
void HALSIM_GetSPIGetTransactionBuffer(int32_t index, uint8_t* buffer, int32_t count)
{
	SimSPIData[index].GetTransactionBuffer(buffer, count);
}

} // extern c
