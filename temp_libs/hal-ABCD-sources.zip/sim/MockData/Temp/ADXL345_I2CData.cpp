/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "MockData/NotifyListener.h"
#include "../ADXL345_I2CDataInternal.h"

using namespace hal;

#ifdef __cplusplus
extern "C" {
#endif


void* HALSIM_CreateADXL345I2CAccelerometerData(int32_t port)
{
	return new ADXL345_I2CData(port);
}
void HALSIM_DestroyADXL345I2CAccelerometerData(void* data)
{
	delete (ADXL345_I2CData*) data;
}


void HALSIM_ResetADXL345I2CAccelerometerData(void* data)
{
	((ADXL345_I2CData*) data)->ResetData();
}

int32_t HALSIM_RegisterADXL345I2CAccelerometerXCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL345_I2CData*) data)->RegisterXCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL345I2CAccelerometerXCallback(void* data, int32_t uid)
{
	((ADXL345_I2CData*) data)->CancelXCallback(uid);
}
double HALSIM_GetADXL345I2CAccelerometerX(void* data)
{
	return ((ADXL345_I2CData*) data)->GetX();
}
void HALSIM_SetADXL345I2CAccelerometerX(void* data, double x)
{
	((ADXL345_I2CData*) data)->SetX(x);
}

int32_t HALSIM_RegisterADXL345I2CAccelerometerYCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL345_I2CData*) data)->RegisterYCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL345I2CAccelerometerYCallback(void* data, int32_t uid)
{
	((ADXL345_I2CData*) data)->CancelYCallback(uid);
}
double HALSIM_GetADXL345I2CAccelerometerY(void* data)
{
	return ((ADXL345_I2CData*) data)->GetY();
}
void HALSIM_SetADXL345I2CAccelerometerY(void* data, double y)
{
	((ADXL345_I2CData*) data)->SetY(y);
}

int32_t HALSIM_RegisterADXL345I2CAccelerometerZCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL345_I2CData*) data)->RegisterZCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL345I2CAccelerometerZCallback(void* data, int32_t uid)
{
	((ADXL345_I2CData*) data)->CancelZCallback(uid);
}
double HALSIM_GetADXL345I2CAccelerometerZ(void* data)
{
	return ((ADXL345_I2CData*) data)->GetZ();
}
void HALSIM_SetADXL345I2CAccelerometerZ(void* data, double z)
{
	((ADXL345_I2CData*) data)->SetZ(z);
}

#ifdef __cplusplus
}
#endif
