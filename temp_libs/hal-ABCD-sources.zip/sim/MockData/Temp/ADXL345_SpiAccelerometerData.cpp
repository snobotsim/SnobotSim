/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "MockData/NotifyListener.h"
#include "../ADXL345_SpiAccelerometerDataInternal.h"

using namespace hal;

#ifdef __cplusplus
extern "C" {
#endif


void* HALSIM_CreateADXL345SPIAccelerometerData(int32_t port)
{
	return new ADXL345_SpiAccelerometer(port);
}
void HALSIM_DestroyADXL345SPIAccelerometerData(void* data)
{
	delete (ADXL345_SpiAccelerometer*) data;
}


void HALSIM_ResetADXL345SPIAccelerometerData(void* data)
{
	((ADXL345_SpiAccelerometer*) data)->ResetData();
}

int32_t HALSIM_RegisterADXL345SPIAccelerometerXCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL345_SpiAccelerometer*) data)->RegisterXCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL345SPIAccelerometerXCallback(void* data, int32_t uid)
{
	((ADXL345_SpiAccelerometer*) data)->CancelXCallback(uid);
}
double HALSIM_GetADXL345SPIAccelerometerX(void* data)
{
	return ((ADXL345_SpiAccelerometer*) data)->GetX();
}
void HALSIM_SetADXL345SPIAccelerometerX(void* data, double x)
{
	((ADXL345_SpiAccelerometer*) data)->SetX(x);
}

int32_t HALSIM_RegisterADXL345SPIAccelerometerYCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL345_SpiAccelerometer*) data)->RegisterYCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL345SPIAccelerometerYCallback(void* data, int32_t uid)
{
	((ADXL345_SpiAccelerometer*) data)->CancelYCallback(uid);
}
double HALSIM_GetADXL345SPIAccelerometerY(void* data)
{
	return ((ADXL345_SpiAccelerometer*) data)->GetY();
}
void HALSIM_SetADXL345SPIAccelerometerY(void* data, double y)
{
	((ADXL345_SpiAccelerometer*) data)->SetY(y);
}

int32_t HALSIM_RegisterADXL345SPIAccelerometerZCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL345_SpiAccelerometer*) data)->RegisterZCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL345SPIAccelerometerZCallback(void* data, int32_t uid)
{
	((ADXL345_SpiAccelerometer*) data)->CancelZCallback(uid);
}
double HALSIM_GetADXL345SPIAccelerometerZ(void* data)
{
	return ((ADXL345_SpiAccelerometer*) data)->GetZ();
}
void HALSIM_SetADXL345SPIAccelerometerZ(void* data, double z)
{
	((ADXL345_SpiAccelerometer*) data)->SetZ(z);
}

#ifdef __cplusplus
}
#endif
