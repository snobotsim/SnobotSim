/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "MockData/NotifyListener.h"
#include "../ADXL362_SpiAccelerometerDataInternal.h"

using namespace hal;

#ifdef __cplusplus
extern "C" {
#endif


void* HALSIM_CreateADXL362SPIAccelerometerData(int32_t port)
{
	return new ADXL362_SpiAccelerometer(port);
}
void HALSIM_DestroyADXL362SPIAccelerometerData(void* data)
{
	delete (ADXL362_SpiAccelerometer*) data;
}


void HALSIM_ResetADXL362SPIAccelerometerData(void* data)
{
	((ADXL362_SpiAccelerometer*) data)->ResetData();
}

int32_t HALSIM_RegisterADXL362SPIAccelerometerXCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL362_SpiAccelerometer*) data)->RegisterXCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL362SPIAccelerometerXCallback(void* data, int32_t uid)
{
	((ADXL362_SpiAccelerometer*) data)->CancelXCallback(uid);
}
double HALSIM_GetADXL362SPIAccelerometerX(void* data)
{
	return ((ADXL362_SpiAccelerometer*) data)->GetX();
}
void HALSIM_SetADXL362SPIAccelerometerX(void* data, double x)
{
	((ADXL362_SpiAccelerometer*) data)->SetX(x);
}

int32_t HALSIM_RegisterADXL362SPIAccelerometerYCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL362_SpiAccelerometer*) data)->RegisterYCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL362SPIAccelerometerYCallback(void* data, int32_t uid)
{
	((ADXL362_SpiAccelerometer*) data)->CancelYCallback(uid);
}
double HALSIM_GetADXL362SPIAccelerometerY(void* data)
{
	return ((ADXL362_SpiAccelerometer*) data)->GetY();
}
void HALSIM_SetADXL362SPIAccelerometerY(void* data, double y)
{
	((ADXL362_SpiAccelerometer*) data)->SetY(y);
}

int32_t HALSIM_RegisterADXL362SPIAccelerometerZCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXL362_SpiAccelerometer*) data)->RegisterZCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXL362SPIAccelerometerZCallback(void* data, int32_t uid)
{
	((ADXL362_SpiAccelerometer*) data)->CancelZCallback(uid);
}
double HALSIM_GetADXL362SPIAccelerometerZ(void* data)
{
	return ((ADXL362_SpiAccelerometer*) data)->GetZ();
}
void HALSIM_SetADXL362SPIAccelerometerZ(void* data, double z)
{
	((ADXL362_SpiAccelerometer*) data)->SetZ(z);
}

#ifdef __cplusplus
}
#endif
