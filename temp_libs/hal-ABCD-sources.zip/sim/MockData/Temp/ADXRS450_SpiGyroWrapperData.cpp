/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include "HAL/HAL.h"
#include "MockData/NotifyListener.h"
#include "../ADXRS450_SpiGyroWrapperDataInternal.h"

using namespace hal;

#ifdef __cplusplus
extern "C" {
#endif

void* HALSIM_CreateADXRS450SPIGyroData(int32_t port)
{
	return new ADXRS450_SpiGyroWrapper(port);
}
void HALSIM_DestroyADXRS450SPIGyroData(void* data)
{
	delete (ADXRS450_SpiGyroWrapper*) data;
}

void HALSIM_ResetADXRS450SPIData(void* data)
{
	((ADXRS450_SpiGyroWrapper*) data)->ResetData();
}

int32_t HALSIM_RegisterADXRS450SPIGyroAngleCallback(void* data,
                                                 HAL_NotifyCallback callback,
                                                 void* param,
                                                 HAL_Bool initialNotify)
{
	return ((ADXRS450_SpiGyroWrapper*) data)->RegisterAngleCallback(callback, param, initialNotify);
}
void HALSIM_CancelADXRS450SPIGyroAngleCallback(void* data, int32_t uid)
{
	((ADXRS450_SpiGyroWrapper*) data)->CancelAngleCallback(uid);
}
double HALSIM_GetADXRS450SPIGyroAngle(void* data)
{
	return ((ADXRS450_SpiGyroWrapper*) data)->GetAngle();
}
void HALSIM_SetADXRS450SPIGyroAngle(void* data, double angle)
{
	((ADXRS450_SpiGyroWrapper*) data)->SetAngle(angle);
}

#ifdef __cplusplus
}
#endif
